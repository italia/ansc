# JWT/JWS Generator and Validator

All'interno di questo repository è possibile trovare due tool.

1. Un tool per la generazione e la validazione di JSON Web Signature (JWS). Questo tool è rappresentato dalla main
   class `JWSGeneratorAndValidate`.
2. Un tool per la generazione del JWT, JWS, http header del JWS detached e successiva chiamata al servizio cooperativo
   di ANSC. Questo tool è rappresentato dalla main class `TestCallRestServiceWithJWS`.

Per utilizzare questi tool è necessario avere installato almeno Java 11 e Maven 3.6.

## 1. Descrizione e uso del tool JWSGeneratorAndValidate

Per default, il tool genera un JWS da un KeyPair RSA 4096 bit auto-generato e un payload di esempio. Il payload di
esempio è:

```json
{
  "data": "This is some text that is to be signed."
}
```

Source Code 1 - Payload di esempio usato per la generazione del JWS

Passando come argomento il path di un file contenente la chiave pubblica in formato PEM e un file contenente il JWS
nella forma:
**Base64URLEncoded(header).Base64URLEncoded(payload).Base64URLEncoded(Signature of Base64URLEncoded(header)
.Base64URLEncoded(payload))**

Per impostazione predefinita, il tool utilizza l'algoritmo di firma RS256, senza quindi estrarlo dall'header del JWS.

```json
{
  "alg": "RS256",
  "typ": "JWT"
}
```

Source Code 2 - Header del JWS

La libreria JOSE4J è stata utilizzata per la generazione e la validazione del JWS, indicata sulla
pagina [JWT.io](https://jwt.io/#libraries-io). La documentazione della libreria è disponibile all'interno della
[Wiki](https://bitbucket.org/b_c/jose4j/wiki/Home">JOSE4J)

### 1.1 Esempio di utilizzo

Per eseguire il tool è necessario eseguire il comando:

```bash
# Generazione e verifica del JWS di default
$ mvn compile exec:java -Dexec.mainClass="it.interno.ansc.lib.tool.java.security.jwt.JwsGeneratorAndValidate"

# Generazione e verifica del JWS con chiave pubblica e JWS passati come argomento
$ mvn compile exec:java -Dexec.mainClass="it.interno.ansc.lib.tool.java.security.jwt.JwsGeneratorAndValidate" -Dexec.args="<path-to-public-key-file> <path-to-jws-file>"
```

Console 1 - Esempio di utilizzo del tool

Nel secondo caso di esecuzione è necessario sostituire i parametri **<path-to-public-key-file>** e **<path-to-jws-file>**
con i path dei file contenenti la chiave pubblica e il JWS. All'interno della cartella
[resources](src/main/resources) è possibile trovare un file di esempio contenente la
[chiave pubblica](src/main/resources/jws/public_key_pub_for_jws_0000.pem) e un file di esempio contenente il
[JWS](src/main/resources/jws/jws_0000.jws) nella forma Compact Serialization.

A seguire è possibile vedere un esempio di output del tool. Ho escluso dall'output la parte relativa a Maven, ritenuta
di non interesse allo scopo.

```bash
Starting generate JSON Web Signature (JWS) with RSA 256...
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
JWS payload: {"data": "This is some text that is to be signed."}
Generated Private Key: MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQC/sCOl4OsQclku5FoEf0SQowjSJCvPawYlw+K+Fisd8fr52w/onm7lXWFv/FNThthik9QawDNjvc7l9Hj75Te4f4uacbkU6IABEd0pT+WW34kU6I/0iey7dSHE9r9yjoxvFb/y55HY5u3jmz/WXL6EpHEuydI+TB/D33yCs20gd3mvdO5YWRqGMBPgIiOKq+p3+bsIu9bptVTs0GilXIx8rQa3FdUhQedMonqztYVPY8IrmpQe/SoBhqro/2rFe8UGSP5zjRZE7zD8Ri6MkampAQC0KsLbd0KwEC8IJ7MT/lZQliKrHy5nW52653rzworlFdDYqICmX9RxyY2gMKq6WqSqjC48elq+qfGJ5b7ggxl6Kac7VIi3Vffn3xm5DZkbv/F6S0ef3RnRopRxEanrMQ3W7VrXa7cQ0JyjaI42bp+l5wyNvyqebmWdiVwgHTIgTCdU4Fv3TwQwpjdCeiFuVxmhufpgLDdQSvXvmUGYRfXG5+K/Y5hExniYaQg4sikFPRBCOx2UVHQLPAwj+Zi+tYfoPhkf1X83dxo+/CxE5QhIErzUb9bnOCZ976SaVbCs5ienRtU6HTIbot8nfPEgOGljghNiJGV91SvSS1WZJaDohOzAtuEla7WaKwKkDjmHWgsCGvDOXBA4Emdxn3zZPTyadXhlu8I/Zitj32AOMQIDAQABAoICAGKAU8Ews/oumG+FPlCjSYt9i9HYbn7Wg0EyyLhfUebAavSrwiAKEfhhJOnT4snAOD9nsY3RiFbPuZrnJqhiYGC5gfZqS+5Xjzd9g4VwHg2KbrnEy/ygR3sItMKu/TAT2kxXA90BbCvmdwYHyCUSYYBttA+T/CqxGX2gwS20n/YYDvq/fp79oqij2gLJ6DOhJgpi1N6nD8fmu245phybU0HZ8+JvIKdHY2E4+Q6Rz6A9JhEcDNNjyosgNYEnhylV8afKKJ8eN/xSYXyxX8gyLdm/vynV822teiJZHqH1LIuwnZAppkUC7+iC5qmdu8u5A4C21iwPYpScF+Ik7VcMyx22Jx4hc0yA8KCYLnp+1XxEmV8Cg1KRR51L/UX1zXvWIN/+DPISGmcemET1Yr+D/vNkyDtUsnBF8Uik8aPurtiX57/HGewFy1tL/C7UC4AhyA6jhja5BROAaPviEhLtsq9iyf3LSgAYz42hXbkeltSyhYiSu3MvYE5xHUzHGLbcEt/9HibalI4mOZY9cLcqCgHX9Lqpolg9qm2euIgW8JUV807yv7UOnCKzANpcXZlfv3ge7f7C3/2F3q9c0xn415BSTpra5bebKleje6nnAwqANRX1Q5syLfhgK81ckK6cmLafj2bSwVCowYXLlGgmcRIhoA9vp17Xu2ul0KKJjFvVAoIBAQDjwyLIpGu84YUHhM3phvgQRQBM9CSBjK1rog++4DwSgadEDSBDZufWh6Lg1KHG5SPSC0f11BGxiGFrOOPN5FCj5+yvlt4Mbq1XSpE3d8WPPJM3tQgOeycoeEEpzKNizVvVBfvfMzDlfW+eu1Z0HJNJIH16LJfnaG+ztwfziG6ZFL7RFvbLIrVrtZ1kq23fIkm0si8+vWs+pZVoYr8DXgpEXRpfH7aEvGb4OnMoAjVAO70+8AoGvuS93GcvsevudSSvFCnvQoIsza5rj2NSBoJC+4OYyeF6Cu5Zm7Ii2kwlrrQ40hj8SmWso32b/MOMMv0eULznF146BcokzBHmOpSHAoIBAQDXdA6gqKfRmgWn73RQkPHxPXzlYr1FvMA0lWy06qeLl9h3/ip3jqw8TdEnLCI4XJCr/pjfUxq15/CftvrHxf27NS7kFlxoyFrCBFngp9ndS8IJNl/j+qt79mD8SKZYRaTOMGCplulR5zPpRGxmSIg4LWOTfc/FcKM39d81dZahA3W2KDJqNv56+naTTEYI0WtEDy27oK78nZnO/7Go/6Ovht+5Q613EC7nVBclYL/KmN66m61EmM4GyCc5FtEmQRtR4S1ee2IVyX0DIZiKwkfSngy/m/RwsZ3dzumKszNy55XxM+AcULZvJNu/0vgAmCzQeowq753rXcrFmbp6oC2HAoIBACfvWBL8GVPl6vBVjdErdCVOI+5aRGhepS2hHcenA4FvMEfTUVvgGDhaUem//pmkJbK3faeRxoRtWD93myHHrYf/q1ViS468fTI4BdxG6OHjiiCTYlU/rK8A3tQYaHFzdm2UfgQ1spYad07KpC75r617v+SDGyNdAXDuX7uIqXO32nlI4H7fmBXJo046bKpaFbhUIcqLZdl3KQpDfiB2BbDU7kHNirAdZKSTgwt5z6Jylw0JA4kJQYw0r/cB6E9IROVZ0Lx92dtHORTs8Eo6j+50sS9B/oHqlr4peYN46S8WQc1QsUbTOJ6bj/Ogzxyu+AivuV9/jmr4BuiKy3ylutMCggEBAKhc8/VN9l5Pmu3hrCYtLjOTFh92qmttlVFCF0HFQQpPrYQPJQZqgmNZeADBdzhN9WvCN5oEqhHOXvWgGpa0PJPnem4YnzvunSWSGt34rMJGqiliyUoxH4JuRNnAt+Sw/5l0qoS7/jXXk3RM2NyQ/4nOxkqCfTNP0uwvAa8X5Y6LUpf3D3Z65SAay0BN0Uigxc7YgadmaHfVfFUK8L0cj7/hiMCQh2RMTCrPRosZ8KYUEbEHaD37nrwj+qqdDvFy3TN94GM9zacy3bLttPNx4IhQo6uz5i+OTMwBHfUaFjFLkZt8KzxVQkrWJbbf2Jc2U4bSzOfcea5si8EgYV3j/88CggEAdqzg42M5rf2gvRqQ/dpn8jqxdtBqO5foZp01G+yxOYAUUBDir5cTqkmUgwvcuBEBgPYEjDlxhpy0kYCL7qalzJCM9IbE5tWk+GGTNgoMCZ0PHtG4DiIJIeyHKtqBoZyxtrfeiTDUh4c6XckoLeHpIA6HWCp3LMh1vxtSgkH0969INiuG+BVPXfHLbP9o4OSIn9qRmq9TByVV0QXKQ74A/7riHcYGlXT2Nj9x4zKb4LhRnIL/V/gZmTFJs0Gc4P8AY5UHfcmgyDNYvRF2+f9OUi2Sxvc5ATQLFmyQZhByHevCTMeKNPc5xiiKAasCa+3pFBJbn91lKbfEZUyqsQbxFg==
Generated Public Key: MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv7AjpeDrEHJZLuRaBH9EkKMI0iQrz2sGJcPivhYrHfH6+dsP6J5u5V1hb/xTU4bYYpPUGsAzY73O5fR4++U3uH+LmnG5FOiAARHdKU/llt+JFOiP9Insu3UhxPa/co6MbxW/8ueR2Obt45s/1ly+hKRxLsnSPkwfw998grNtIHd5r3TuWFkahjAT4CIjiqvqd/m7CLvW6bVU7NBopVyMfK0GtxXVIUHnTKJ6s7WFT2PCK5qUHv0qAYaq6P9qxXvFBkj+c40WRO8w/EYujJGpqQEAtCrC23dCsBAvCCezE/5WUJYiqx8uZ1uduud688KK5RXQ2KiApl/UccmNoDCqulqkqowuPHpavqnxieW+4IMZeimnO1SIt1X3598ZuQ2ZG7/xektHn90Z0aKUcRGp6zEN1u1a12u3ENCco2iONm6fpecMjb8qnm5lnYlcIB0yIEwnVOBb908EMKY3QnohblcZobn6YCw3UEr175lBmEX1xufiv2OYRMZ4mGkIOLIpBT0QQjsdlFR0CzwMI/mYvrWH6D4ZH9V/N3caPvwsROUISBK81G/W5zgmfe+kmlWwrOYnp0bVOh0yG6LfJ3zxIDhpY4ITYiRlfdUr0ktVmSWg6ITswLbhJWu1misCpA45h1oLAhrwzlwQOBJncZ982T08mnV4ZbvCP2YrY99gDjECAwEAAQ==
JWS Signature is valid: true
Verify Signature Std API: true
Starting generate JSON Web Signature (JWS) with RSA 256...[END]
Starting validate JSON Web Signature (JWS) with RSA 256 from external resources...
	Public Key Path: C:\jws-signature-verify\public_key_pub.pem
	JWS Compact Serialization Path: C:\jws-signature-verify\jws_0000.jws
	JWS Header: {"alg":"RS256","typ":"JWT"}
	JWS Payload: {
"testataRichiesta": {
"idComune": 3655,
"idOperazioneComune": "APP2022032210000",
"dataOraRichiesta": "2022-08-17",
"nomeApplicativo": "Applicativo Demografico",
"versioneApplicativo": "1.0.0",
"fornitoreApplicativo": "Nome Fornitore"
},
"allegatoInput": {
"contenuto": "QU5TQw==",
"nomefile": "mionomefile",
"tipoFile": "1",
"tipoAllegato": "1"
}
}
	Verify Signature from External public key and JWS: true
Starting validate JSON Web Signature (JWS) with RSA 256 from external resources...[END]
```

Console 2 - Output del tool per la generazione e verifica del JWS

## 2. Descrizione e uso del tool TestCallRestServiceWithJWS

Il tool serve essenzialmente per costruire correttamente la chiamata verso i servizi cooperativi di ANSC che utilizzano
come meccanismo di sicurezza il JWS (JSON Web Signature) con algoritmo di firma RSA256.

Gli step che segue il tool sono in ordine i seguenti:

1. Generazione del KeyPair partendo dal PKCS#12 di postazione, quest'ultimo deve essere in proprio possesso
2. Estrazione del certificato pubblico dal KeyPair
3. Lettura del payload in formato JSON che rappresenta il body della richiesta da inviare al servizio cooperativo
4. Generazione del JWT specifico dei servizi cooperativi di ANSC e firmato con la chiave privata del KeyPair
5. Generazione del JWS firmato con la chiave privata del KeyPair
6. Invocazione del servizio cooperativo di ANSC passando il JWS come header della richiesta

Il tool accetta una serie di parametri in ingresso che vengono passati come argomenti da riga di comando.
Il comando a seguire mostra tutti i parametri accettati dal tool:

```bash
# Sostituire il valore di $version con la versione corrente del tool
$ java -jar dist-jwt-jws-generate-signature-verify-$version.jar --help
```

Console 3 - Visualizzazione dei parametri accettati dal tool

La tabella a seguire descrive il significato di ogni parametro previsto dal tool. I parametri mostrati sono quelli
estesi e non quelli abbreviati (che sono preceduti da un solo trattino e che potete vedere tramite --help).

| Parametro          | Descrizione                                                                                     | Required | Default |
|--------------------|-------------------------------------------------------------------------------------------------|----------|---------|
| --help             | Visualizza l'help del tool                                                                      | No       | false   |
| --pkcs12-file      | Path del file PKCS#12 di postazione (esempio: /016017-PC-0001.16196C7A.p12)                     | Si       | -       |
| --pkcs12-password  | Password del file PKCS#12 di postazione                                                         | Si       | -       |
| --alias-key        | Alias della chiave contenuta nel file PKCS#12 (esempio: 016017-pc-0001)                         | Si       | -       |
| --payload-json     | Payload JSON della richiesta al servizio REST (esempio: /payload/service_upload_file_0000.json) | Si       | -       |
| --subject          | Subject del claim 'sub' del token JWT                                                           | Si       | -       |
| --sede             | Sede del claim 'sede' del token JWT                                                             | Si       | -       |
| --postazione       | Postazione del claim 'postazione' del token JWT                                                 | Si       | -       |
| --otp              | OTP del claim 'otp' del token JWT                                                               | No       | 123456  |
| --jwt-exp          | JWT Expire Time in seconds del claim 'exp' del token JWT                                        | No       | 3600    |
| --service-endpoint | Service EndPoint URL del servizio REST                                                          | Si       | -       |
| --debug            | Abilita l'output delle varie parti del token JWT e JWS                                          | No       | false   |

Tabella 1 - Parametri accettati dal tool

A seguire l'output dell'help in linea del tool.

```text
Usage: <main class> [options]
  Options:
  * --alias-key, -ak
      Alias della chiave contenuta nel file PKCS#12
    --debug
      Debug mode. Mostra i dettagli del token JWT/JWS
      Default: false
    --help
      Visualizzazione dell'help
    --jwt-exp, -jwt-exp
      JWT Expire Time in seconds del claim 'exp' del token JWT
      Default: 3600
    --otp, -otp
      OTP del claim 'otp' del token JWT
      Default: 123456
  * --payload-json, -data
      Payload JSON della richiesta al servizio REST
  * --pkcs12-file, -pkcs12
      Path completo del file PKCS#12
  * --pkcs12-password, -pkcs12-pwd
      Password del file PKCS#12
  * --postazione, -p
      Postazione del claim 'postazione' del token JWT
  * --sede, -s
      Sede del claim 'sede' del token JWT
  * --service-endpoint, -endpoint
      Service EndPoint URL del servizio REST
  * --subject, -sub
      Subject del claim 'sub' del token JWT
```

Console 4 - Output dell'help in linea del tool

### 2.1 Esempio di utilizzo del tool TestCallRestServiceWithJWS

Prima di eseguire il tool è necessario che abbiate a disposizione il file PKCS#12 di postazione e il payload JSON che
vi rappresenta il body della richiesta da inviare al servizio cooperativo di ANSC.

Allegato al file PKCS#12 di postazione dovreste avere:

1. la password di accesso al file PKCS#12
2. l'alias della chiave

L'alias della chiave corrisponde nella maggior parte dei casi al nome della postazione (esempio: 016017-pc-0001).
Per verificare l'alias della chiave potete aprire il file PKCS#12 con il vostro client preferito (esempio: KeyStore
Explorer)
oppure eseguire il comando a seguire:

```bash
$ openssl pkcs12 -info -in 016017-PC-0001.16196C7A.p12
```

Console 5 - Visualizzazione dell'alias della chiave

Tra le informazioni visualizzate dal comando dovreste trovare l'alias della chiave (esempio: 016017-PC-0001).

```text
...
MAC: sha1, Iteration 102400
MAC length: 20, salt length: 20
PKCS7 Data
Shrouded Keybag: pbeWithSHA1And3-KeyTripleDES-CBC, Iteration 51200
Bag Attributes
localKeyID: 5A CF 1C D9 D5 98 A3 ED 14 3B 1A 03 EE 16 F1 21 9A AE EC 3A
friendlyName: 016017-PC-0001
Key Attributes: <No Attributes>
...
```

Console 6 - Parte dell'output del comando di visualizzazione dell'alias della chiave

Se volessimo eseguire per esempio una chiamata al servizio di upload file di ANSC, il payload JSON che dovremmo
utilizzare è il seguente:

```json
{
  "testataRichiesta": {
    "idComune": 580,
    "idOperazioneComune": "APP2022032210000",
    "dataOraRichiesta": "2022-08-17",
    "nomeApplicativo": "Applicativo Demografico",
    "versioneApplicativo": "1.0.0",
    "fornitoreApplicativo": "Nome Fornitore"
  },
  "allegatoInput": {
    "contenuto": "QU5TQw==",
    "nomefile": "mionomefile",
    "tipoFile": "1",
    "tipoAllegato": "1"
  }
}
```

Source 1 - Payload JSON di esempio per il servizio di upload file di ANSC

Per il formato dei payload JSON di esempio per i vari servizi di ANSC potete consultare la documentazione ufficiale
delle
OpenAPI di ANSC. All'interno di questo progetto è presente un file JSON che rappresenta il payload JSON di esempio per
il servizio di upload file di ANSC (
esempio: [service_upload_file_0000.json](src/main/resources/payload/service_upload_file_0000.json)).

Per eseguire il tool, quindi effettuare la chiamata al servizio, è sufficiente lanciare il seguente comando:

```bash
# Sostituire il valore di $version con la versione corrente del tool
$ java -jar dist-jwt-jws-generate-signature-$version.jar \
	--pkcs12-file C:\\jws-signature-verify\\src\\main\\resources\\pkcs12\\016017-PC-0001.16196C7A.p12 \
	--pkcs12-password 16196C7A \
	--alias-key 016017-pc-0001 \
	--subject MSRNTN77H15C351X \
	--sede 016017 \
	--postazione 016017-PC-0001 \
	--otp 123456 \
	--jwt-exp 3600 \
	--payload-json C:\\jws-signature-verify\\src\\main\\resources\\payload\\service_upload_file_0000.json \
	--service-endpoint https://anscservicepre.anpr.interno.it/services/service/doc/allegato/upload/1
```

Console 7 - Esempio di esecuzione del tool per la chiamata al servizio di upload file di ANSC

Nel caso mostrato in console 7, è stato utilizzato un PKCS#12 di postazione di test (esempio:
016017-PC-0001.16196C7A.p12)
presente all'interno di questo progetto (
esempio: [016017-PC-0001.16196C7A.p12](src/main/resources/pkcs12/016017-PC-0001.16196C7A.p12))
e il payload JSON di esempio per il servizio di upload file di ANSC (
esempio: [service_upload_file_0000.json](src/main/resources/payload/service_upload_file_0000.json)).

A seguire, è riportato l'output dell'esecuzione del tool:

```text
======================================== JWT,JWS and HTTP Header ========================================
JWT: eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsIng1YyI6WyJNSUlFNnpDQ0F0T2dBd0lCQWdJSVp0cHRGUjZVd3lJd0RRWUpLb1pJaHZjTkFRRUxCUUF3V2pFYk1Ca0dBMVVFQXd3U1EwRWdVRzl6ZEdGNmFXOXVhU0JUZG1sc01RMHdDd1lEVlFRT
ERBUkJUbEJTTVI4d0hRWURWUVFLREJaTmFXNXBjM1JsY204Z1pHVnNiQ2RKYm5SbGNtNXZNUXN3Q1FZRFZRUUdFd0pKVkRBZUZ3MHlNakEzTWpZeE1ETTBNVFphRncweU5URXdNRFV4TVRBNU1qUmFNSUdaTVJjd0ZRWURWUVFEREE0d01UWXdNVGN0VUV
NdE1EQXdNVEVkTUJzR0ExVUVDd3dVVUc5emRHRjZhVzl1YVNCa2FTQnNZWFp2Y204eE1UQXZCZ05WQkFzTUtFRnVZV2R5WVdabElFNWhlbWx2Ym1Gc1pTQlFiM0J2YkdGNmFXOXVaU0JTWlhOcFpHVnVkR1V4SHpBZEJnTlZCQW9NRmsxcGJtbHpkR1Z5Y
nlCa1pXeHNKMGx1ZEdWeWJtOHhDekFKQmdOVkJBWVRBa2xVTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUFoY2hyK0d4NnVBSkxFcWtUWkM4aTlDTFZaK0kwZGZmQTZKT0VyUFdFQWV2WXFXbldCMTkycEdLK3lyS21FQ1d
4YkNzaUpvSjlRbHJFcEFjODJyTERBb1pONHpvVldmMmhGSHVXWk80YjBRQnc2ZFNZSFBUNGhaM20yL1BGNkNKQ0laQktXNGhvT2xmTW5kNFd0ZEEvY0Q1S0hhRHJJTnQ0dzRVS2kxamJ3SnJ5Mm1TbU0zYmNpZzlxVy9oTlo2ODNNM1dIaXdEMjB1bmtBV
WF0RHRtTERySUhMbXM1UzlrWFo1N3lTWEZhYXI3WGgzUjdxU091K3hyaXhWUFVSUlJzYmttNkRmRmphUDhEek5MVlVqY21DWnFqdk1JTjl6dEd6dHNoQTEycjdURWtkT1BDbUhyVW9POGdobnpjZ3g4MERTeTk4Y0p0Z3hBNmlOSkF3UWpDaFFJREFRQUJ
vM1V3Y3pBTUJnTlZIUk1CQWY4RUFqQUFNQjhHQTFVZEl3UVlNQmFBRkFZTG44cWgxNW10MUNMdXM0dXhGSlBJVjV0K01CTUdBMVVkSlFRTU1Bb0dDQ3NHQVFVRkJ3TUNNQjBHQTFVZERnUVdCQlJhenh6WjFaaWo3UlE3R2dQdUZ2RWhtcTdzT2pBT0JnT
lZIUThCQWY4RUJBTUNCNEF3RFFZSktvWklodmNOQVFFTEJRQURnZ0lCQUt1MVZ6eERQVVVOaWtQK2cydzhxVHZwbXV5dDdJdHVLZmt4cWJla29ZbFJJL1NMV1hSWGpyT1N6am9nQnE2M0ZnTjl0UjJVbGVFdGNYMFhiR2hGMlVGYm5FUkU1WDZ0UkxjbVY
zaG5KNVYrWlA5SEdPNmhaRmlHK2hrZ2FFRm9xY3VuMUpCOUtycFRPVG5xOU9yc1BYSGRNMlZDWFFoU0tEeTlpL2lRNnpjVVBqd0wrZDVrOVE3L2tDUSs3ZnJaZ3NyKzZWU3hDZUZhdU4zaDh5ajU2S2EraVNDczlFSEFZaUZMbXQvZXdyVFBaWmxjOHVUc
G9USlhOY3lMVXV5MkRTR0o3OE1CSjRwOXdPSFdIMGRoa1lEU2tIempIeTljc3BVUDNpWjZxNkhGRE41NzR5SjdWUlp1TnJFdVFKclcwdFRVUnV0WHphYVE0MkVFRlYxbXVrbzJpSDdaTXlmTEJ6VXZoQXZrR3p2VXVkUjNuNGtJc3lqOUp3TzdpdkEvTjN
keFplMzMwTTYzR0FyYkhLSXFnZXhCRWtsN1dsdzBiUXdENFo5QlRacW9BRFErQitPZE5TZVhjSFdva3pkOC9TTzI0VUp4ejB0bklXUlYzcFo4NzZ5bGczd3UwSEdmd1V6ZVZMOC9tQ2xTYUg4RHo1UmIrNUpOZmZPYTV4eVZGU0I1ZER5UDVTT0ZHa1dzU
HNQNzlhSktyS2EyanpxU1NnellpdTBwT3U2MFJBNjk4N2JQU3hZcWxSdVIwcGNMODN1Uldab1RWOVF5TTlTRmlUbTJJUXdWNjdXYnYyS25yQnRYb1hpNE5YY0ZYMzZsb0xEYWwyMkdpWVRRVi9SbGxNS1l2Wk9iVnFRMGZvVTNObTFoN3dtcnVIaXYzenV
BdTlGelprUjVWNGVHIl19.eyJzdWIiOiJNU1JOVE43N0gxNUMzNTFYIiwiaWF0IjoxNjcxNzE1ODIzLCJleHAiOjE2NzE5MzE4MjMsIm5iZiI6MTY3MTkzMTgyMywianRpIjoidlpubXQ3VV9ubXpHM1g5OW9tLXZXdyIsInNlZGUiOiIwMTYwMTciLCJw
b3N0YXppb25lIjoiMDE2MDE3LVBDLTAwMDEiLCJvdHAiOiIxMjM0NTYifQ.SFhKUijjC56lmZm4jQnhes-GZRtteBzz6M7daOwi2WGIGhbQtUC8wsjNJWZkGsemz8nunxRjfsRW1bW4oWNP0xP3Idyl4nibYmD8gRgul_8nxlrAOopYcwx3oNcRdjksDFh
Bo5QGoSGDT8dcvokffXnbWTU1v3TIsbktyBxuBFx9HT8bw3MFF52uPwUSKnqo1QpK_0DbauybC-j-wvPuHCzhq3AszB1xdAwkcbVimaPPZ_L3N4UeFa7oHlvuqVcI3a5kojiugDPI4A3aud1gSoomvtYaQJXBwYzX5mbNi3lEbQhFnrMKmvzGwb-G1LLu-
F5N1zsj405JykxABgP-tA
JWS: eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.ewogICJ0ZXN0YXRhUmljaGllc3RhIjogewogICAgImlkQ29tdW5lIjogNTgwLAogICAgImlkT3BlcmF6aW9uZUNvbXVuZSI6ICJBUFAyMDIyMDMyMjEwMDAwIiwKICAgICJkYXRhT3JhUmljaGll
c3RhIjogIjIwMjItMDgtMTciLAogICAgIm5vbWVBcHBsaWNhdGl2byI6ICJBcHBsaWNhdGl2byBEZW1vZ3JhZmljbyIsCiAgICAidmVyc2lvbmVBcHBsaWNhdGl2byI6ICIxLjAuMCIsCiAgICAiZm9ybml0b3JlQXBwbGljYXRpdm8iOiAiTm9tZSBGb3
JuaXRvcmUiCiAgfSwKICAiYWxsZWdhdG9JbnB1dCI6IHsKICAgICJjb250ZW51dG8iOiAiUVU1VFF3PT0iLAogICAgIm5vbWVmaWxlIjogIm1pb25vbWVmaWxlIiwKICAgICJ0aXBvRmlsZSI6ICIxIiwKICAgICJ0aXBvQWxsZWdhdG8iOiAiMSIKICB9
Cn0.Cn3Xu8Lbn9TKoZHC4AadHXP0EzYESoX2u81xo_3vdzP9vTkxU78f6uMrP6cswqaaMBA3DqWIahqiqLKp29_E7uWKS0wN8eV7SKemtuvwt_r5y9K3CRAPg1NOuclQ9aEPx4HOqBOunh2_4fVOq0QvizSgSvvuTZ7S00y7at1r2u4bFn6vs1O3vdArXb
rUTn2PUNsQ7V2kHle57BXUiVAVYf1AY_KT64diqeLC-lVS1lNKY9_7OCH72ZAegUlVJ_IDGLg_DyShq5y8xG4SEegVQtmkzE9b_T9fvNNe_fvWTjyOViXn38q-Ynox6UBmd6FSomIixLy89-d3vpJ2_zg5AQ
JWS to HTTP Header: eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9..Cn3Xu8Lbn9TKoZHC4AadHXP0EzYESoX2u81xo_3vdzP9vTkxU78f6uMrP6cswqaaMBA3DqWIahqiqLKp29_E7uWKS0wN8eV7SKemtuvwt_r5y9K3CRAPg1NOuclQ9aEPx4HO
qBOunh2_4fVOq0QvizSgSvvuTZ7S00y7at1r2u4bFn6vs1O3vdArXbrUTn2PUNsQ7V2kHle57BXUiVAVYf1AY_KT64diqeLC-lVS1lNKY9_7OCH72ZAegUlVJ_IDGLg_DyShq5y8xG4SEegVQtmkzE9b_T9fvNNe_fvWTjyOViXn38q-Ynox6UBmd6FSom
IixLy89-d3vpJ2_zg5AQ
======================================== JWT,JWS and HTTP Header ========================================

================================================================================
Call REST Service with JWS...
Service EndPoint: https://anscservicepre.anpr.interno.it/services/service/doc/allegato/upload/1
HttpResponse Code: 200
HttpResponse Body: {"testataRisposta":{"idComune":580,"idOperazioneComune":"APP2022032210000","idOperazione":"610403","idEsito":0},"allegatoOutput":{"idAllegato":"610404","statoAllegato":"1"
,"contenuto":"QU5TQw==","idDocumentum":"","nomefile":"mionomefile","tipoFile":"1","tipoAllegato":"1","hash":"Hr5QsD8ggv+3bNepReRXQWzVN/rLhySqlYMBTvnmNqE="}}
Call REST Service with JWS...[END]
================================================================================
```

Console 8 - Output del comando eseguito in precedenza

Le informazioni riportate in output possono essere utili nel caso di problemi d'integrazione. Utilizzando il parametro
opzionale --debug è possibile visualizzare anche le informazioni utili per la risoluzione dei problemi. In particolare,
le informazioni di debug includono: il token JWT, il token JWS e l'header HTTP utilizzato in formato encoded.
