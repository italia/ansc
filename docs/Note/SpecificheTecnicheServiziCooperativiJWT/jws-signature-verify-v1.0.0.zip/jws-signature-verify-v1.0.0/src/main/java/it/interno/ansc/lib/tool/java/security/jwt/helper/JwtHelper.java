/*-
 * =====LICENSE-START=====
 * JWT/JWS Generator and Validator
 * ------
 * Copyright (C) 2022 - 2023 SOGEI S.p.A
 * ------
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * =====LICENSE-END=====
 */

package it.interno.ansc.lib.tool.java.security.jwt.helper;

import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwx.HeaderParameterNames;
import org.jose4j.lang.JoseException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.cert.Certificate;
import java.util.*;

/**
 * Questa classe contiene metodi di utilità per la gestione dei JWT/JWS.
 *
 * @author Antonio Musarra
 */
public class JwtHelper {

  /**
   * Genera un JWS con algoritmo RS256 in compact serialization.
   *
   * @param payload il payload del JWS, ovvero il contenuto da firmare (può essere un JSON di una
   *     richiesta REST)
   * @param keyPair la coppia di chiavi RSA
   * @return il JWS in compact serialization
   * @throws JoseException se si verifica un errore durante la generazione del JWS
   */
  public static String generateJwsAsCompactSerialization(String payload, KeyPair keyPair)
      throws JoseException {

    // Create a new JsonWebSignature
    JsonWebSignature jws = new JsonWebSignature();

    // Set the payload, or signed content, on the JWS object
    jws.setPayload(payload);

    // Set the signature algorithm on the JWS that will integrity protect the payload
    jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);

    // Set the header typ to JWT
    jws.setHeader(HeaderParameterNames.TYPE, "JWT");

    // Set the signing key on the JWS
    // Note that your application will need to determine where/how to get the key
    // and here we just use an example from the JWS spec
    jws.setKey(keyPair.getPrivate());

    // Sign the JWS and produce the compact serialization or complete JWS representation, which
    // is a string consisting of three dot ('.') separated base64url-encoded
    // parts in the form Header.Payload.Signature
    return jws.getCompactSerialization();
  }

  /**
   * Genera un claim JWT.
   *
   * <p>Il claim è un JSON che contiene informazioni sul soggetto che si presenta verso il servizio.
   * Il claim è firmato con una chiave privata RSA e viene inviato al servizio per autenticarsi. A
   * seguire un esempio di claim:
   *
   * <pre>
   *         {
   *            "sub": "MSRNTN77H15C351X",
   *            "iat": 1671694399,
   *            "exp": 1671910399,
   *            "nbf": 1671910399,
   *            "jti": "maB0qn_hnLGz4Tbv4ZRKQQ",
   *            "sede": "016017",
   *            "postazione": "016017-PC-0001",
   *            "otp": "123456"
   *        }
   *    </pre>
   *
   * @param subject     il subject del claim
   * @param sede        l'identificativo della sede
   * @param postazione  l'identificativo della postazione
   * @param otp         Il codice OTP. Il valore di questo parametro dovrà provenire da un dispositivo di
   *                    autenticazione che in questo caso corrisponderà alla chiamata verso il servizio OTP
   *                    realizzato appositamente per il progetto. Il valore di default per questo parametro è
   *                    123456.
   * @param expiration  il tempo di scadenza del claim in secondi.
   * @param keyPair     la coppia di chiavi RSA
   * @param certificate il certificato X.509
   * @return il claim JWT
   * @throws Exception se si verifica un errore durante la generazione del claim
   */
  public static String generateJwtClaim(
      String subject,
      String sede,
      String postazione,
      String otp,
      int expiration,
      KeyPair keyPair,
      Certificate certificate)
      throws Exception {

    JwtClaims jwtClaims = new JwtClaims();
    jwtClaims.setSubject(subject); // set sub
    jwtClaims.setIssuedAtToNow(); // set iat
    jwtClaims.setExpirationTimeMinutesInTheFuture(expiration); // set exp
    jwtClaims.setNotBefore(jwtClaims.getExpirationTime()); // set nbf
    jwtClaims.setGeneratedJwtId(); // set jti
    jwtClaims.setClaim("sede", sede); // set sede
    jwtClaims.setClaim("postazione", postazione); // set postazione
    jwtClaims.setClaim("otp", otp); // set otp

    List<String> chainStrings;
    chainStrings = new ArrayList<>();
    chainStrings.add(Base64.getEncoder().encodeToString(certificate.getEncoded()));

    JsonWebSignature jws = new JsonWebSignature();
    jws.setAlgorithmConstraints(AlgorithmConstraints.NO_CONSTRAINTS);
    jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
    jws.setHeader(HeaderParameterNames.TYPE, "JWT");
    jws.setHeader(HeaderParameterNames.X509_CERTIFICATE_CHAIN, chainStrings);

    jws.setKey(keyPair.getPrivate());
    jws.setPayload(jwtClaims.toJson());

    return jws.getCompactSerialization();
  }

  /**
   * Restituisce il contenuto di un file di testo come stringa. Questo metodo è utile per leggere il
   * body JSON di una richiesta verso un servizio REST.
   *
   * @param fileContentPath il percorso del file di testo
   * @return il contenuto del file di testo in formato stringa
   * @throws IOException se si verifica un errore durante la lettura del file
   */
  public static String getFileContent(String fileContentPath) throws IOException {
    Path filePath = Path.of(fileContentPath);
    return Files.readString(filePath);
  }

  /**
   * Restituisce il payload da un JWS in compact serialization letto da un file di testo.
   *
   * @param jwsFilePath il percorso del file di testo contenente il JWS in compact serialization
   * @return il payload del JWS
   * @throws IOException se si verifica un errore durante la lettura del file
   */
  public static String getPayload(String jwsFilePath) throws IOException {
    return getPayloadFromJwsCompactSerialization(getFileContent(jwsFilePath));
  }

  /**
   * Restituisce l'header da un JWS in compact serialization.
   *
   * @param jwsFilePath il percorso del file di testo contenente il JWS in compact serialization
   * @return l'header del JWS
   * @throws IOException se si verifica un errore durante la lettura del file
   */
  public static String getHeader(String jwsFilePath) throws IOException {
    return getHeaderFromJwsCompactSerialization(getFileContent(jwsFilePath));
  }

  /**
   * Restituisce la signature da un JWS in compact serialization.
   *
   * @param jwsFilePath il percorso del file di testo contenente il JWS in compact serialization
   * @return la signature del JWS
   * @throws IOException se si verifica un errore durante la lettura del file
   */
  public static String getSignature(String jwsFilePath) throws IOException {
    return getSignatureFromJwsCompactSerialization(getFileContent(jwsFilePath));
  }

  /**
   * Restituisce il payload da un JWS in compact serialization.
   *
   * @param jwsCompactSerialization il JWS in compact serialization
   * @return il payload del JWS
   * @throws java.util.regex.PatternSyntaxException se l'espressione regolare non è valida
   * @throws java.lang.ArrayIndexOutOfBoundsException se per qualche motivo il JWS non è valido e di
   *     conseguenza il payload non può essere estratto
   */
  public static String getPayloadFromJwsCompactSerialization(String jwsCompactSerialization) {
    return jwsCompactSerialization.split("\\.", 3)[1];
  }

  /**
   * Restituisce l'header da un JWS in compact serialization.
   *
   * @param jwsCompactSerialization il JWS in compact serialization
   * @return l'header del JWS
   * @throws java.util.regex.PatternSyntaxException se l'espressione regolare non è valida
   * @throws java.lang.ArrayIndexOutOfBoundsException se per qualche motivo il JWS non è valido e di
   *     conseguenza l'header non può essere estratto.
   */
  public static String getHeaderFromJwsCompactSerialization(String jwsCompactSerialization) {
    return jwsCompactSerialization.split("\\.", 3)[0];
  }

  /**
   * Restituisce la signature da un JWS in compact serialization.
   *
   * @param jwsCompactSerialization il JWS in compact serialization
   * @return la signature del JWS
   * @throws java.util.regex.PatternSyntaxException se l'espressione regolare non è valida
   * @throws java.lang.ArrayIndexOutOfBoundsException se per qualche motivo il JWS non è valido e di
   *     conseguenza la signature non può essere estratta.
   */
  public static String getSignatureFromJwsCompactSerialization(String jwsCompactSerialization) {
    return jwsCompactSerialization.split("\\.", 3)[2];
  }

  /**
   * Restituisce una mappa contenente l'header, il payload e la signature di un JWT o JWS che sono
   * in formato compact serialization. La mappa ha come chiavi "header", "payload" e "signature".
   *
   * @param jwsCompactSerialization il JWT o JWS in formato compact serialization
   * @return una mappa contenente l'header, il payload e la signature del JWT o JWS
   * @throws java.util.regex.PatternSyntaxException se l'espressione regolare non è valida
   * @throws java.lang.ArrayIndexOutOfBoundsException se per qualche motivo il JWS non è valido e di
   *     conseguenza i singoli elementi non possono essere estratti.
   */
  public static Map<String, String> getEncodedToken(String jwsCompactSerialization) {
    Base64.Decoder decoder = Base64.getUrlDecoder();
    String[] parts = jwsCompactSerialization.split("\\.");
    String header = new String(decoder.decode(parts[0]));
    String payload = new String(decoder.decode(parts[1]));
    String signature = parts[2];

    Map<String, String> encodedToken = new HashMap<>();
    encodedToken.put("header", header);
    encodedToken.put("payload", payload);
    encodedToken.put("signature", signature);

    return encodedToken;
  }

  /**
   * Esegue la verifica della signature di un JWS in compact serialization tramite il key pair RSA.
   *
   * @param jwsCompactSerialization il JWS in compact serialization
   * @param keyPair la coppia di chiavi RSA
   * @return true se la verifica è andata a buon fine, false altrimenti
   * @throws JoseException se si verifica un errore durante la verifica della signature
   */
  public static boolean verifySignatureJwsAsCompactSerialization(
      String jwsCompactSerialization, KeyPair keyPair) throws JoseException {

    // Create a new JsonWebSignature
    JsonWebSignature jws = new JsonWebSignature();

    // Set the algorithm constraints based on what is agreed upon or expected from the sender
    jws.setAlgorithmConstraints(
        new org.jose4j.jwa.AlgorithmConstraints(
            AlgorithmConstraints.ConstraintType.PERMIT, AlgorithmIdentifiers.RSA_USING_SHA256));

    // Set the compact serialization on the JWS
    jws.setCompactSerialization(jwsCompactSerialization);

    // Set the verification key
    // Note that your application will need to determine where/how to get the key
    // Here we use an example from the JWS spec
    jws.setKey(keyPair.getPublic());

    // Check the signature
    boolean signatureVerified = jws.verifySignature();

    // Get the payload, or signed content, from the JWS
    String payload = jws.getPayload();

    // Do something useful with the content
    System.out.println("JWS payload: " + payload);

    return signatureVerified;
  }
}
