/*-
 * =====LICENSE-START=====
 * JWT/JWS Generator and Validator
 * ------
 * Copyright (C) 2022 - 2023 SOGEI S.p.A
 * ------
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * =====LICENSE-END=====
 */

package it.interno.ansc.lib.tool.java.security.jwt;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import it.interno.ansc.lib.tool.java.security.jwt.helper.JwtHelper;
import it.interno.ansc.lib.tool.java.security.jwt.helper.SecurityCertificateHelper;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.KeyPair;
import java.security.cert.Certificate;
import java.time.Duration;
import java.util.Map;

import static java.time.temporal.ChronoUnit.SECONDS;

/**
 * Tool che consente d'invocare uno dei servizi cooperativi di ANSC.
 *
 * <p>Gli step che segue il tool sono in ordine i seguenti:
 *
 * <ol>
 *   1. Generazione del KeyPair partendo dal PKCS#12 di postazione, quest'ultimo deve essere in
 *   vostro possesso
 * </ol>
 *
 * <ol>
 *   2. Estrazione del certificato pubblico dal KeyPair
 * </ol>
 *
 * <ol>
 *   3. Lettura del payload in formato JSON che rappresenta il body della richiesta da inviare al
 *   servizio cooperativo
 * </ol>
 *
 * <ol>
 *   4. Generazione del JWT specifico dei servizi cooperativi di ANSC e firmato con la chiave
 *   privata del KeyPair
 * </ol>
 *
 * <ol>
 *   5. Generazione del JWS firmato con la chiave privata del KeyPair
 * </ol>
 *
 * <ol>
 *   6. Invocazione del servizio cooperativo di ANSC passando il JWS come header della richiesta
 * </ol>
 *
 * <p>Il tool accetta una serie di parametri in ingresso che vengono passati come argomenti da riga
 * di comando. Il comando a seguire mostra tutti i parametri accettati dal tool:
 *
 * <pre>
 *     java -jar dist-jwt-jws-generate-signature-verify-1.0-SNAPSHOT.jar --help
 * </pre>
 * <p>
 * A seguire un esempio d'invocazione del tool che in questo caso specifico invoca il servizio di
 * upload dei documenti.
 * </p>
 * <pre>
 *     java -jar dist-jwt-jws-generate-signature-verify-1.0-SNAPSHOT.jar \
 *        --pkcs12-file C:\\workspace\\git\\ansc\\ansc-projects\\jws-signature-verify\\src\\main\\resources\\pkcs12\\016017-PC-0001.16196C7A.p12 \
 *        --pkcs12-password 16196C7A \
 *        --alias-key 016017-pc-0001 \
 *        --subject MSRNTN77H15C351X \
 *        --sede 016017 \
 *        --postazione 016017-PC-0001 \
 *        --otp 123456 \
 *        --jwt-exp 3600 \
 *        --payload-json C:\\workspace\\git\\ansc\\ansc-projects\\jws-signature-verify\\src\\main\\resources\\payload\\service_upload_file_0000.json \
 *        --service-endpoint https://anscservicepre.anpr.interno.it/services/service/doc/allegato/upload/1 \
 *        --debug
 * </pre>
 *
 * @author Antonio Musarra
 */
public class TestCallRestServiceWithJws {

  @Parameter(
      names = {"--pkcs12-file", "-pkcs12"},
      description = "Path completo del file PKCS#12",
      required = true)
  String pkcs12FilePath;

  @Parameter(
      names = {"--pkcs12-password", "-pkcs12-pwd"},
      description = "Password del file PKCS#12",
      required = true)
  String pkcs12Password;

  @Parameter(
      names = {"--alias-key", "-ak"},
      description = "Alias della chiave contenuta nel file PKCS#12",
      required = true)
  String aliasKey;

  @Parameter(
      names = {"--payload-json", "-data"},
      description = "Payload JSON della richiesta al servizio REST",
      required = true)
  String payloadAsJson;

  @Parameter(
      names = {"--subject", "-sub"},
      description = "Subject del claim 'sub' del token JWT",
      required = true)
  String subject;

  @Parameter(
      names = {"--sede", "-s"},
      description = "Sede del claim 'sede' del token JWT",
      required = true)
  String sede;

  @Parameter(
      names = {"--postazione", "-p"},
      description = "Postazione del claim 'postazione' del token JWT",
      required = true)
  String postazione;

  @Parameter(
      names = {"--otp", "-otp"},
      description = "OTP del claim 'otp' del token JWT",
      required = false)
  String otp = "123456";

  @Parameter(
      names = {"--jwt-exp", "-jwt-exp"},
      description = "JWT Expire Time in seconds del claim 'exp' del token JWT",
      required = false)
  int jwtExpireTime = 3600;

  @Parameter(
      names = {"--service-endpoint", "-endpoint"},
      description = "Service EndPoint URL del servizio REST",
      required = true)
  String serviceEndPoint;

  @Parameter(names = "--help", description = "Visualizzazione dell'help", help = true)
  boolean help;

  @Parameter(names = "--debug", description = "Debug mode. Mostra i dettagli del token JWT/JWS")
  boolean debug = false;

  /**
   * Entry point del tool.
   *
   * @param args argomenti da riga di comando
   * @throws Exception eccezione generica
   */
  public static void main(String[] args) throws Exception {
    TestCallRestServiceWithJws testCallRestServiceWithJws = new TestCallRestServiceWithJws();
    JCommander.newBuilder().addObject(testCallRestServiceWithJws).build().parse(args);
    testCallRestServiceWithJws.run();
  }

  public void run() throws Exception {

    if (help) {
      JCommander.newBuilder().addObject(this).build().usage();
      return;
    }

    KeyPair keyPair =
        SecurityCertificateHelper.getKeyPairFromPkcs12(pkcs12FilePath, pkcs12Password, aliasKey);

    Certificate certificate =
        SecurityCertificateHelper.getCertificateFromPkcs12(
            pkcs12FilePath, pkcs12Password, aliasKey);

    String payload = JwtHelper.getFileContent(payloadAsJson);

    String jwt =
        JwtHelper.generateJwtClaim(
            subject, sede, postazione, otp, jwtExpireTime, keyPair, certificate);

    String jws = JwtHelper.generateJwsAsCompactSerialization(payload, keyPair);
    String jwsToHttpHeader =
        String.format(
            "%s..%s",
            JwtHelper.getHeaderFromJwsCompactSerialization(jws),
            JwtHelper.getSignatureFromJwsCompactSerialization(jws));

    String separatorHeader =
        String.format("%s JWT,JWS and HTTP Header %s", "=".repeat(40), "=".repeat(40));
    System.out.println(separatorHeader);
    System.out.println("JWT: " + jwt);
    System.out.println("JWS: " + jws);
    System.out.println("JWS to HTTP Header: " + jwsToHttpHeader);
    System.out.println(separatorHeader);
    System.out.println();

    if (debug) {
      Map<String, String> jwtToken = JwtHelper.getEncodedToken(jwt);
      Map<String, String> jwsToken = JwtHelper.getEncodedToken(jws);

      String separatorDebugHeader =
          String.format(
              "%s Decoded JWT and JWS in payload, header and signature %s",
              "=".repeat(40), "=".repeat(40));
      System.out.println(separatorDebugHeader);
      System.out.println("JWT Header: " + jwtToken.get("header"));
      System.out.println("JWT Payload: " + jwtToken.get("payload"));
      System.out.println("JWT Signature: " + jwtToken.get("signature"));

      System.out.println("JWS Header: " + jwsToken.get("header"));
      System.out.println("JWS Payload: " + jwsToken.get("payload"));
      System.out.println("JWS Signature: " + jwsToken.get("signature"));
      System.out.println(separatorDebugHeader);
      System.out.println();
    }

    System.out.println("=".repeat(80));
    System.out.println("Call REST Service with JWS...");
    System.out.println("Service EndPoint: " + serviceEndPoint);

    HttpRequest request =
        HttpRequest.newBuilder()
            .uri(new URI(serviceEndPoint))
            .headers(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
            .headers(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
            .headers("JWS", jwsToHttpHeader)
            .timeout(Duration.of(10, SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(payload))
            .build();

    HttpClient client =
        HttpClient.newBuilder().sslContext(SecurityCertificateHelper.getSslContext()).build();

    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

    System.out.println("HttpResponse Code: " + response.statusCode());
    System.out.println("HttpResponse Body: " + response.body());

    if (response.statusCode() != 200) {
      throw new AssertionError("Response code is not 200");
    }

    System.out.println("Call REST Service with JWS...[END]");
    System.out.println("=".repeat(80));
  }
}
