/*-
 * =====LICENSE-START=====
 * JWT/JWS Generator and Validator
 * ------
 * Copyright (C) 2022 - 2023 SOGEI S.p.A
 * ------
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * =====LICENSE-END=====
 */

package it.interno.ansc.lib.tool.java.security.jwt;

import it.interno.ansc.lib.tool.java.security.jwt.helper.JwtHelper;
import it.interno.ansc.lib.tool.java.security.jwt.helper.SecurityCertificateHelper;
import org.jose4j.lang.JoseException;

import java.io.IOException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Tool per la generazione e la validazione di JSON Web Signature (JWS). Per default, il tool genera
 * un JWS da un KeyPair RSA 4096 bit auto-generato e un payload di esempio. Passando come argomento
 * il path di un file contenente una chiave pubblica in formato PEM e un file contenente il JWS
 * nella forma: Base64URLEncoded(header).Base64URLEncoded(payload).Base64URLEncoded(Signature of
 * Base64URLEncoded(header).Base64URLEncoded(payload)) Per impostazione predefinita, il tool
 * utilizza l'algoritmo di firma RS256.
 *
 * <p>In questo esempio è stata utilizzata la libreria JOSE4J per la generazione e la validazione
 * del JWS, indicata sulla pagina <a href="https://jwt.io/#libraries-io">JWT.io</a>. La
 * documentazione della libreria è disponibile su <a
 * href="https://bitbucket.org/b_c/jose4j/wiki/Home">JOSE4J Wiki</a>
 *
 * <p>Esempio di esecuzione:
 *
 * <pre>
 *  java -jar dist-jwt-jws-generate-signature-verify-1.0-SNAPSHOT.jar
 *  java -jar dist-jwt-jws-generate-signature-verify-1.0-SNAPSHOT.jar \
 *    path-to-public-key-file path-to-jws-file
 * </pre>
 *
 * @author Antonio Musarra
 */
public class JwsGeneratorAndValidate {

  /**
   * Application entry point
   *
   * @param args path-to-public-key-file path-to-jws-file
   * @throws IOException if an I/O error occurs reading from the stream
   * @throws NoSuchAlgorithmException if a particular cryptographic algorithm is requested but is
   *     not available in the environment
   * @throws InvalidKeySpecException if the given key specification is inappropriate for this key
   *     factory to produce a public key
   * @throws JoseException if an error occurs while generating or validating the JWS
   */
  public static void main(String[] args)
      throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, JoseException {

    System.out.println("Starting generate JSON Web Signature (JWS) with RSA 256...");

    // Generate a key pair
    KeyPair keyPair = SecurityCertificateHelper.generateKeyPair();

    // The content that will be signed
    String examplePayload = "{\"data\": \"This is some text that is to be signed.\"}";

    // Generate a JWS object in compact serialization form
    String jwsCompactSerialization =
        JwtHelper.generateJwsAsCompactSerialization(examplePayload, keyPair);

    // Verify the JWS signature with internal API
    boolean verifySignature =
        JwtHelper.verifySignatureJwsAsCompactSerialization(jwsCompactSerialization, keyPair);

    // Verify the JWS with external API
    boolean verifySignatureStdApi =
        verifySignature(
            keyPair.getPublic(),
            JwtHelper.getHeaderFromJwsCompactSerialization(jwsCompactSerialization),
            JwtHelper.getPayloadFromJwsCompactSerialization(jwsCompactSerialization),
            JwtHelper.getSignatureFromJwsCompactSerialization(jwsCompactSerialization));

    // Do something useful with the result of signature verification
    System.out.println(
        "Generated Private Key: "
            + Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded()));
    System.out.println(
        "Generated Public Key: "
            + Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded()));
    System.out.println("JWS Signature is valid: " + verifySignature);
    System.out.println("Verify Signature Std API: " + verifySignatureStdApi);
    System.out.println("Starting generate JSON Web Signature (JWS) with RSA 256...[END]");

    if (args.length == 2) {
      String publicKeyPath = args[0];
      String jwsCompactSerializationPath = args[1];

      System.out.println(
          "Starting validate JSON Web Signature (JWS) with RSA 256 from external resources...");
      System.out.println("\tPublic Key Path: " + publicKeyPath);
      System.out.println("\tJWS Compact Serialization Path: " + jwsCompactSerializationPath);
      System.out.println(
          "\tJWS Header: "
              + new String(
                  Base64.getUrlDecoder().decode(JwtHelper.getHeader(jwsCompactSerializationPath))));
      System.out.println(
          "\tJWS Payload: "
              + new String(
                  Base64.getUrlDecoder()
                      .decode(JwtHelper.getPayload(jwsCompactSerializationPath))));

      // Verify the JWS signature with external JWS and public key
      boolean verifySignatureFromExternal =
          verifySignature(
              getPublicKey(publicKeyPath),
              JwtHelper.getHeader(jwsCompactSerializationPath),
              JwtHelper.getPayload(jwsCompactSerializationPath),
              JwtHelper.getSignature(jwsCompactSerializationPath));

      System.out.println(
          "\tVerify Signature from External public key and JWS: " + verifySignatureFromExternal);
    }

    System.out.println(
        "Starting validate JSON Web Signature (JWS) with RSA 256 from external resources...[END]");
  }

  private static boolean verifySignature(
      PublicKey publicKey, String header, String payload, String signature) {
    try {
      String data = header + "." + payload;
      Signature sig = Signature.getInstance("SHA256withRSA");
      sig.initVerify(publicKey);
      sig.update(data.getBytes());
      byte[] decodedSignature = Base64.getUrlDecoder().decode(signature);
      return sig.verify(decodedSignature);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  private static PublicKey getPublicKey(String publicKeyPemFilePath)
      throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

    byte[] encoded = Base64.getDecoder().decode(JwtHelper.getFileContent(publicKeyPemFilePath));

    X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
    KeyFactory kf = KeyFactory.getInstance("RSA");

    return kf.generatePublic(keySpec);
  }
}
