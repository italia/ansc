/*-
 * =====LICENSE-START=====
 * JWT/JWS Generator and Validator
 * ------
 * Copyright (C) 2022 - 2023 SOGEI S.p.A
 * ------
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * =====LICENSE-END=====
 */

package it.interno.ansc.lib.tool.java.security.jwt.helper;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.*;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Vector;

/**
 * Questa classe contiene metodi di utilità per la gestione dei certificati necessari per la firma e
 * verifica di JWT/JWS.
 *
 * @author Antonio Musarra
 */
public class SecurityCertificateHelper {

  /**
   * Estrapola il KeyPair dal file PKCS#12. Il keypair è estratto dalla entry con alias indicato.
   *
   * @param pkcs12FilePath Path del file PKCS#12
   * @param password Password del file PKCS#12
   * @param alias Alias della entry nel file PKCS#12
   * @return KeyPair estratto dal file PKCS#12
   * @throws KeyStoreException Errore durante l'accesso al KeyStore
   * @throws IOException Errore durante la lettura del file PKCS#12
   * @throws NoSuchAlgorithmException Errore durante l'accesso al KeyStore
   * @throws CertificateException Errore durante l'accesso al KeyStore
   * @throws UnrecoverableKeyException Errore durante l'accesso al KeyStore
   */
  public static KeyPair getKeyPairFromPkcs12(String pkcs12FilePath, String password, String alias)
      throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException,
          UnrecoverableKeyException {

    KeyStore keyStore = getKeyStoreFromPkcs12(pkcs12FilePath, password);

    Key key = keyStore.getKey(alias, password.toCharArray());
    java.security.cert.Certificate certificate = keyStore.getCertificate(alias);

    return new KeyPair(certificate.getPublicKey(), (PrivateKey) key);
  }

  /**
   * Estrapola il certificato dal file PKCS#12. Il certificato è estratto dalla entry con alias
   * indicato.
   *
   * @param pkcs12FilePath Path del file PKCS#12
   * @param password Password del file PKCS#12
   * @param alias Alias della entry nel file PKCS#12
   * @return Certificato estratto dal file PKCS#12
   * @throws KeyStoreException Errore durante l'accesso al KeyStore
   * @throws IOException Errore durante la lettura del file PKCS#12
   * @throws NoSuchAlgorithmException Errore durante l'accesso al KeyStore
   * @throws CertificateException Errore durante l'accesso al KeyStore
   */
  public static Certificate getCertificateFromPkcs12(
      String pkcs12FilePath, String password, String alias)
      throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException {

    KeyStore keyStore = getKeyStoreFromPkcs12(pkcs12FilePath, password);

    return keyStore.getCertificate(alias);
  }

  /**
   * Restituisce il KeyStore caricato dal file PKCS#12.
   *
   * @param pkcs12FilePath Path del file PKCS#12
   * @param password Password del file PKCS#12
   * @return KeyStore caricato dal file PKCS#12
   * @throws KeyStoreException Errore durante l'accesso al KeyStore
   * @throws IOException Errore durante la lettura del file PKCS#12
   * @throws NoSuchAlgorithmException Errore durante l'accesso al KeyStore
   * @throws CertificateException Errore durante l'accesso al KeyStore
   */
  public static KeyStore getKeyStoreFromPkcs12(String pkcs12FilePath, String password)
      throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException {

    KeyStore keyStore = KeyStore.getInstance("PKCS12");
    FileInputStream fis = new FileInputStream(pkcs12FilePath);
    keyStore.load(fis, password.toCharArray());
    fis.close();

    return keyStore;
  }

  /**
   * Genera un KeyPair utilizzando l'algoritmo RSA con chiave di lunghezza 4096 bit.
   *
   * @return KeyPair
   * @throws NoSuchAlgorithmException Errore durante la generazione del KeyPair
   */
  public static KeyPair generateKeyPair() throws NoSuchAlgorithmException {
    // Creating KeyPair generator object
    KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");

    // Initializing the KeyPairGenerator
    keyPairGen.initialize(4096);

    // Generating the pair of keys
    return keyPairGen.generateKeyPair();
  }

  /**
   * Genera un certificato self-signed utilizzando l'algoritmo SHA256withRSA.
   *
   * @param dn Distinguished Name del certificato
   * @param issuerDn Distinguished Name dell'issuer del certificato
   * @param keyPair Chiave pubblica e privata del certificato @see {@link #generateKeyPair()}
   * @return Certificato self-signed
   * @throws IOException Errore durante la generazione del certificato
   * @throws OperatorCreationException Errore durante la generazione del certificato
   * @throws CertificateException Errore durante la generazione del certificato
   */
  public static X509Certificate generateX509Certificate(String dn, String issuerDn, KeyPair keyPair)
      throws IOException, OperatorCreationException, CertificateException {

    Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

    final long YESTERDAY = System.currentTimeMillis() - 24 * 60 * 60 * 1000;
    final long ONE_YEAR_FROM_NOW = System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000;
    final String SIGNATURE_ALGORITHM = "SHA256withRSA";
    final String PROVIDER = "BC";

    SubjectPublicKeyInfo subPubKeyInfo =
        SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded());
    Date startDate = new Date(YESTERDAY);
    Date endDate = new Date(ONE_YEAR_FROM_NOW);

    X509v3CertificateBuilder certBuilder =
        new X509v3CertificateBuilder(
            new X500Name(issuerDn),
            BigInteger.valueOf(System.currentTimeMillis()),
            startDate,
            endDate,
            new X500Name(dn),
            subPubKeyInfo);

    // Set certificate extensions
    // (1) digitalSignature extension
    certBuilder.addExtension(
        X509Extension.keyUsage,
        true,
        new KeyUsage(
            KeyUsage.digitalSignature
                | KeyUsage.keyEncipherment
                | KeyUsage.dataEncipherment
                | KeyUsage.keyAgreement));

    // (2) extendedKeyUsage extension
    Vector<KeyPurposeId> ekUsages = new Vector<>();
    ekUsages.add(KeyPurposeId.id_kp_clientAuth);
    ekUsages.add(KeyPurposeId.id_kp_serverAuth);
    certBuilder.addExtension(X509Extension.extendedKeyUsage, false, new ExtendedKeyUsage(ekUsages));

    // Sign the certificate
    PrivateKey privateKey = keyPair.getPrivate();
    ContentSigner sigGen =
        new JcaContentSignerBuilder(SIGNATURE_ALGORITHM).setProvider(PROVIDER).build(privateKey);
    X509CertificateHolder certificateHolder = certBuilder.build(sigGen);
    return new JcaX509CertificateConverter()
        .setProvider(PROVIDER)
        .getCertificate(certificateHolder);
  }

  /**
   * Restituisce un contesto SSL utile per quelle comunicazioni dove il certificato del server non è
   * attendibile.
   *
   * @return Contesto SSL
   */
  public static SSLContext getSslContext() {
    TrustManager[] noopTrustManager =
        new TrustManager[] {
          new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] xcs, String string) {}

            public void checkServerTrusted(X509Certificate[] xcs, String string) {}

            public X509Certificate[] getAcceptedIssuers() {
              return null;
            }
          }
        };
    try {
      SSLContext sc = SSLContext.getInstance("ssl");
      sc.init(null, noopTrustManager, null);
      return sc;
    } catch (KeyManagementException | NoSuchAlgorithmException ex) {
      System.err.println("Error while creating SSLContext: " + ex.getMessage());
    }
    return null;
  }
}
